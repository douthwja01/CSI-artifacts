this.lgtBar = msg.broken;
