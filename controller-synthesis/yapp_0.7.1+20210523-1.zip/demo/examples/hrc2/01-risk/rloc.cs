if (msg.entity == "ur10-cobot") {
    switch (msg) {
        case TriggerRegionEnterEvent entry:
            if (LOC.TryParse(entry.region, out LOC location)) {
                this.rloc = location;
            }
            break;
        case TriggerRegionExitEvent _:
            // assumes robot remains in cell
            this.rloc = LOC.inCell;
            break;
    }
}
