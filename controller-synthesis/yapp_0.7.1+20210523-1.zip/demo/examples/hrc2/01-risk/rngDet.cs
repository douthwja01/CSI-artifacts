if (msg.distance > nearDist) {
    rngDet = RNGDET.far;
} else if (msg.distance < nearDist && msg.distance > closeDist) {
    rngDet = RNGDET.near;
} else if (msg.distance < closeDist) {
    rngDet = RNGDET.close;
}
