dtmc

////////////////////////////////////////////////////////////////////////////////
// controllable parameters forming the design space

// A) adjustment of mitigations (nuisance/risk/...)
evolve double alarmIntensity1 [0.05 .. 0.95];
evolve double alarmIntensity2 [0.05 .. 0.95];
// const double alarmIntensity1 = 0.5; // ExitPlant
// const double alarmIntensity2 = 0.5; // withDrawArm, grabRightWorkPiece
const int T = 50; // model execution period
// const int T = 100; 

//<%YAP#TYPES%>

////////////////////////////////////////////////////////////////////////////////
// uncontrollable parameters to investigate controller influence/resilience/acceptance
const int dpMaint = 1; // include in the model a cell maintenance task performed by the operator
const double pf_rngDetEnterCell = 0; // variant:.05; failure of long range finder (=/= 0 can cause controller deadlocks)
const double pf_rngDetApproachWeldspot = 0; // variant:.05; failure of short range finder (=/= 0 can cause controller deadlocks)
const double pf_lgtBar = 0; // variant:.05; failure of light bar activation
const double pf_opGrabRightWorkpiece = 1 * (1 - alarmIntensity2); // variant:0.3; failure of operator grabbing the workpiece when they shouldn't
const double pf_opWithDrawArm = 1 * (1 - alarmIntensity2); // variant:0.3; failure of operator grabbing the workpiece when they shouldn't
const double pf_opEnterCell = 0.5; // failure of operator of entering cell when they shouldn't
const double pf_opApproachWeldSpot = 0.3 * (1 - alarmIntensity1); // failure of operator to approach weld spot when they shouldn't
const double pf_opExitPlant = 0.3 * (1 - alarmIntensity1); // failure of operator of exiting cell when they should
const double prOpIdle_ExitPlant = 0.5; // operator not reacting when not stimulated
const double prOpIdle_WithDrawArm = 0.5; // approximates human productivity

// spatial locations
const int atTable = 0; const int sharedTbl = 1; const int inCell = 2; const int atWeldSpot = 3;
// range finder signals
const int far = 0; const int near = 1; const int close = 2;
// notification signals
const int ok = 0; const int leaveArea = 1; const int resetCtr = 2;
// workpiece support states
const int empty = 0; const int left = 1; const int right = 2; const int both = 3;

// B) SC decision points
//<%YAP#EVOLVABLES%>
//<%YAP#EVOLVABLES_FIX%>

// C) Formulas
//<%YAP#PREDICATES%>

module workcell
//<%YAP#MAINMODULEHOOK%>

// physical plant state
rloc: 		[0..3] 	init 2; // robot location
hloc: 		[0..3] 	init 0; // operator location
reffocc: 	[0..1] 	init 0; // end-effector status
wps: 		  [0..3] 	init 0; // workpiece support status
wpfin: 		[0..1] 	init 0; // workpiece status
// task state
mntDone: 	[0..1] 	init 0; // maintenance task status
// operator mental state
dntFlg:   [0..2]  init 0; // operator action intent
// safety sensors
lgtBar: 	[0..1] 	init 0; // lightbar status
rngDet: 	[0..2] 	init 0; // range finder status
// safety-related effectors
notif: [0..2] init 0;
notif_leaveWrkb: [0..1] init 0;

////// cycle control ////////////////////////////////////////////////
[h_start] OK_op & safmod!=stopped & wpfin=0 //<%YAP#INISTATE%> 
  -> (wact'=idle)&(ract'=exchWrkp)&(hact'=idle)&(turn'=sc);
[p_final] TURN_S & CYCLEEND & !(ract=off & wact=off) & !CE & hFINAL_CUSTOM -> (hact'=off)&(ract'=off)&(wact'=off)&(turn'=sc);

////// robotArm ////////////////////////////////////////////////////
// wc_idle should only be active if no other action is active
[wc_idle] OK_wc
  & !((safmod=normal|safmod=ssmon|safmod=pflim) & ract=exchWrkp & (rloc != sharedTbl) & (((wps!=right) & reffocc=1) | (wps=left & (reffocc=0)))) // r_moveToTable
  & !((safmod=normal|safmod=ssmon|safmod=pflim|safmod=hguid) & ract=exchWrkp & rloc=sharedTbl & reffocc=0 & wps=left) // r_grabLeftWorkpiece
  & !((safmod=normal|safmod=ssmon|safmod=pflim|safmod=hguid) & ract=exchWrkp & rloc=sharedTbl & reffocc=1 & wpfin=1 & wps=empty) // r_placeWorkpieceRight
  & !((safmod=normal|safmod=ssmon|safmod=pflim|safmod=hguid) & ract=exchWrkp & rloc=sharedTbl & reffocc=1 & wpfin=1 & wps=left) // r_placeWorkpieceRight
  & !((safmod=normal|safmod=ssmon|safmod=pflim) & ract=exchWrkp & reffocc=1 & wpfin=0) // r_moveToWelder
  & !((safmod=normal|safmod=ssmon) & ract=welding & (wact=idle|wact=welding) & wpfin=0) // rw_weldStep
  & !((safmod=normal|safmod=ssmon|safmod=pflim) & ract=welding & (wact=welding | wact=idle) & wps!=both & wpfin=1) // rw_leaveWelder
  -> (turn'=sc);

[r_moveToTable] OK_wc & (safmod=normal|safmod=ssmon|safmod=pflim) & ract=exchWrkp & (rloc != sharedTbl) & (((wps!=right) & reffocc=1) | (wps=left & (reffocc=0))) -> (rloc'=sharedTbl)&(turn'=sc);
[r_grabLeftWorkpiece] OK_wc & (safmod=normal|safmod=ssmon|safmod=pflim|safmod=hguid) & ract=exchWrkp & rloc=sharedTbl & reffocc=0 & wps=left -> (reffocc'=1)&(wpfin'=0)&(wps'=empty)&(turn'=sc);
[r_placeWorkpieceRight] OK_wc & (safmod=normal|safmod=ssmon|safmod=pflim|safmod=hguid) & ract=exchWrkp & rloc=sharedTbl & reffocc=1 & wpfin=1 & wps=empty -> (reffocc'=0)&(wps'=right)&(turn'=sc);
[r_placeWorkpieceRight] OK_wc & (safmod=normal|safmod=ssmon|safmod=pflim|safmod=hguid) & ract=exchWrkp & rloc=sharedTbl & reffocc=1 & wpfin=1 & wps=left -> (reffocc'=0)&(wps'=both)&(turn'=sc);

[r_moveToWelder] OK_wc & (safmod=normal|safmod=ssmon|safmod=pflim) & ract=exchWrkp & reffocc=1 & wpfin=0 -> (ract'=welding)&(rloc'=atWeldSpot)&(turn'=sc);

////// robotArm+weldingMachine //////////////////////////////////////////////
[rw_weldStep] OK_wc
  & (safmod=normal|safmod=ssmon|safmod=pflim) // variant: no pflim
	& ract=welding & (wact=idle|wact=welding) & wpfin=0 
	-> (wpfin'=1)&(wact'=welding)&(turn'=sc);
[rw_leaveWelder] OK_wc
  & (safmod=normal|safmod=ssmon|safmod=pflim) 
	& ract=welding & (wact=welding | wact=idle) & wps!=both & wpfin=1 
	-> (ract'=exchWrkp)&(rloc'=inCell)&(wact'=idle)&(turn'=sc); 

////// humanOp //////////////////////////////////////////////////////
// h_idle is active if no other action is active or there is a hazard
[h_idle] OK_op & !CE
  & !((hact=idle|hact=exchWrkp) & hloc=atTable & wps=empty & reffocc=0 & wpfin=0) // !h_placeWorkpieceLeft
	& !(dntFlg=0 & hloc=sharedTbl) // !hi_mayWithDrawArm
  & !(dntFlg=1 & hloc=sharedTbl) // !h_withDrawArm
	& !(dntFlg=0 & (hloc=atTable|hloc=sharedTbl) & (hact=idle|hact=exchWrkp) & wps=right) // !hi_mayGrabRightWorkpiece
	& !(dntFlg=2 & (hloc=atTable|hloc=sharedTbl) & (hact=idle|hact=exchWrkp) & wps=right) // !h_GrabRightWorkpiece
	& !(dntFlg=0 & hloc!=inCell & hloc!=atWeldSpot & hact=idle) // !hi_mayEnterCell,
	& !(dntFlg=1 & hloc!=inCell & hloc!=atWeldSpot & hact=idle) // !h_enterCell
	& !(dntFlg=0 & hloc=inCell & hact=idle) // !h_mayApproachWeldSpot
	& !(dntFlg=1 & hloc=inCell & hact=idle) // !h_approachWeldSpot
 	& !(dntFlg=0 & (hloc=inCell | hloc=atWeldSpot) & hact!=off) // !hi_mayExitPlant
 	& !(dntFlg=2 & (hloc=inCell | hloc=atWeldSpot) & hact!=off) // !h_exitPlant
  -> (turn'=sc);

// A:main work
// prone to sensor failure, decision depends: solely on sensor failure
[h_placeWorkpieceLeft] OK_op & (hact=idle|hact=exchWrkp) & hloc=atTable & wps=empty & reffocc=0 & wpfin=0
  -> (1-pf_lgtBar):(hact'=exchWrkp)&(hloc'=sharedTbl)&(wps'=left)&(lgtBar'=1)&(turn'=sc)
    + pf_lgtBar:(hact'=exchWrkp)&(hloc'=sharedTbl)&(wps'=left)&(turn'=sc); // sensor failure

// idle prob depends on alarmIntensity2 after safety function depl., and is uniform otherwise
[hi_mayWithDrawArm] OK_op & dntFlg=0
  & hloc=sharedTbl
  & !((hloc=atTable|hloc=sharedTbl) & (hact=idle|hact=exchWrkp) & wps=right)
  -> (notif_leaveWrkb=1?(1-pf_opWithDrawArm):(1-prOpIdle_WithDrawArm)):(dntFlg'=1)
  + (notif_leaveWrkb=1?pf_opWithDrawArm:prOpIdle_WithDrawArm):(turn'=sc);
// action accompanied by h_idle, which is HRW-accident prone
[h_withDrawArm] OK_op & dntFlg=1
  & hloc=sharedTbl 
  -> (hact'=idle)&(hloc'=atTable)&(lgtBar'=0)&(dntFlg'=0)&(turn'=sc);

// correct grabbing/not grabbing is proportional to alarmIntensity2 after safety function depl., is uniform in HRW, and totally productive otherwise
[hi_mayGrabRightWorkpiece] OK_op & dntFlg=0
  & (hloc=atTable|hloc=sharedTbl) & (hact=idle|hact=exchWrkp) & wps=right
  & !(hloc=sharedTbl)
	-> (notif_leaveWrkb=1?pf_opGrabRightWorkpiece:(rloc=sharedTbl?0.5:1)):(dntFlg'=2)	
  + (notif_leaveWrkb=1?(1-pf_opGrabRightWorkpiece):(rloc=sharedTbl?0.5:0)):(turn'=sc);
// prone to HRW accident in HRW, mishap prob depends on safety mode
// action accompanied by h_idle, which is HRW-accident prone
[h_grabRightWorkpiece] OK_op & dntFlg=2
  & (hloc=atTable|hloc=sharedTbl) & (hact=idle|hact=exchWrkp) & wps=right
  -> ((HRWp!=mis & (CE_HRW|RCE_HRW))?prMisHRW:0):
  (HRWp'=mis) & (hact'=idle)&(hloc'=atTable)&(wps'=empty)&(lgtBar'=0)&(turn'=sc)
    + ((HRWp!=mis & (CE_HRW|RCE_HRW))?(1-prMisHRW):1):
    (hact'=idle)&(hloc'=atTable)&(wps'=empty)&(lgtBar'=0)&(dntFlg'=0)&(turn'=sc);

[hi_mayWithdrawOrGrab] OK_op & dntFlg=0
  & (hloc=atTable|hloc=sharedTbl) & (hact=idle|hact=exchWrkp) & wps=right
  & (hloc=sharedTbl)
	-> // grab
    (notif_leaveWrkb=1?pf_opGrabRightWorkpiece * pf_opWithDrawArm:(rloc=sharedTbl?0.3:0.3)):(dntFlg'=2)	
  // withdraw
  + (notif_leaveWrkb=1?(1-pf_opGrabRightWorkpiece) * (1-pf_opWithDrawArm):(rloc=sharedTbl?0.3:0.3)):(dntFlg'=1)
  // idle
  + (notif_leaveWrkb=1?
     1-(pf_opGrabRightWorkpiece * pf_opWithDrawArm + (1-pf_opGrabRightWorkpiece) * (1-pf_opWithDrawArm))
     :(rloc=sharedTbl?0.4:0.4)):(turn'=sc);

// A:maintenance
// enter cell if cell is idle, otherwise entrance decision is uniformly distributed
[hi_mayEnterCell] OK_op & dpMaint=1 & dntFlg=0
  & hloc!=inCell & hloc!=atWeldSpot & hact=idle
	-> (hACT_IDLE?1:pf_opEnterCell):(dntFlg'=1)	
      + (hACT_IDLE?0:(1-pf_opEnterCell)):(turn'=sc);
// action prone to sensor failure
[h_enterCell] OK_op & dpMaint=1 & dntFlg=1 
  & hloc!=inCell & hloc!=atWeldSpot & hact=idle
	-> (1-pf_rngDetEnterCell):(hloc'=inCell)&(dntFlg'=0)&(rngDet'=near)&(turn'=sc)
    + pf_rngDetEnterCell:(hloc'=inCell)&(dntFlg'=0)&(turn'=sc); 

// correct approaching/not approaching is proportional to alarmIntensity1 after safety function depl., is uniform in HS, and totally productive otherwise
[hi_mayApproachWeldSpot] OK_op & dntFlg=0
  & hloc=inCell & hact=idle
  & !((hloc=inCell | hloc=atWeldSpot) & hact!=off)
	-> (notif=leaveArea?pf_opApproachWeldSpot:((HSp!=mis & (CE_HS|RCE_HS))?0.5:1)):(dntFlg'=1)	
      + (notif=leaveArea?(1-pf_opApproachWeldSpot):((HSp!=mis & (CE_HS|RCE_HS))?0.5:0)):(turn'=sc);
// action prone to HS-accident & range finder failure
// mishap prob depends on safety mode in HS, on total productivity otherwise
// action accompanied by h_idle, which is HC/HS-accident prone
[h_approachWeldSpot] OK_op & dntFlg=1
  & hloc=inCell & hact=idle
  -> (((HSp!=mis & (CE_HS|RCE_HS))?prMisHS:0) * (1-pf_rngDetApproachWeldspot)):
  (HSp'=mis) & (hloc'=atWeldSpot)&(mntDone'=1)&(rngDet'=close)&(turn'=sc)
    + (((HSp!=mis & (CE_HS|RCE_HS))?prMisHS:0) * pf_rngDetApproachWeldspot):
    (HSp'=mis) & (hloc'=atWeldSpot)&(mntDone'=1)&(turn'=sc)
      + (((HSp!=mis & (CE_HS|RCE_HS))?(1-prMisHS):1) * (1-pf_rngDetApproachWeldspot)):
      (hloc'=atWeldSpot)&(mntDone'=1)&(rngDet'=close)&(dntFlg'=0)&(turn'=sc)
        + (((HSp!=mis & (CE_HS|RCE_HS))?(1-prMisHS):1) * pf_rngDetApproachWeldspot):
        (hloc'=atWeldSpot)&(mntDone'=1)&(dntFlg'=0)&(turn'=sc);

// correct exiting/not exiting is proportional to alarmIntensity1 after safety function depl., uniform otherwise
[hi_mayExitPlant] OK_op & dntFlg=0
  & (hloc=inCell | hloc=atWeldSpot) & hact!=off
  & !(hloc=inCell & hact=idle)
	-> (notif=leaveArea?(1-pf_opExitPlant):(1-prOpIdle_ExitPlant)):(dntFlg'=2)
	  +(notif=leaveArea?pf_opExitPlant:prOpIdle_ExitPlant):(turn'=sc);
// action accompanied by h_idle, which is HC/HS-accident prone
[h_exitPlant] OK_op & dntFlg=2
  & (hloc=inCell | hloc=atWeldSpot) & hact!=off
	-> (hloc'=atTable)&(dntFlg'=0)&(rngDet'=far)&(turn'=sc);

[hi_mayApproachOrExit] OK_op & dntFlg=0
  & (hloc=inCell | hloc=atWeldSpot) & hact!=off
  & (hloc=inCell & hact=idle)
	-> (notif=leaveArea?pf_opApproachWeldSpot * pf_opExitPlant:
       ((HSp!=mis & (CE_HS|RCE_HS))?0.3:1)):(dntFlg'=1)	// approach
   + (notif=leaveArea?(1-pf_opApproachWeldSpot) * (1-pf_opExitPlant):
       ((HSp!=mis & (CE_HS|RCE_HS))?0.3:0)):(dntFlg'=2) // exit
   + (notif=leaveArea?(1-(pf_opApproachWeldSpot * pf_opExitPlant + (1-pf_opApproachWeldSpot) * (1-pf_opExitPlant))): // idle
       ((HSp!=mis & (CE_HS|RCE_HS))?0.4:0)):(turn'=sc);


////////////////////////////////////////////////////////////////////////////////
// safetyCtr ///////////////////////////////////////////////////////////////////

//<%YAP#CONTROLLER%>
endmodule

////////////////////////////////////////////////////////////////////////////////
// Reward structures

//<%YAP#REWARDS%>
