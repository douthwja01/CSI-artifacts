using UnityEngine;

using CSI.Messages;
using CSI.Messages.Safety;
using CSI.Messages.System;
using CSI.Messaging.Messengers;

namespace CSI.Robotics {
    //<%YAP#ENUMS%>
        
    public class SafetyController : MonoBehaviour {
        protected ProcessController processController;
        public MessageBroker broker;
        
        [Header("Distance thresholds")]
        public float nearDist = 2.0f;
        public float closeDist = 0.5f;

        [Header("Publication channels")]
        //<%YAP#CHANNELS-OUT%>
        
        [Header("Subscription channels")]
        //<%YAP#CHANNELS-IN%>
        
        //<%YAP#MONCTRVARS%>
        
        //<%YAP#INITIALISER%>
        
        //<%YAP#ATOMIC-EVENT-LIST%>

        //<%YAP#EVENT-DISPATCHER%>

	#region Internal controller logic
        //<%YAP#COMPLEX-EVENT-LIST%>
       	#endregion

        #region Component Behaviours
        private void Awake() {
            processController = this.GetComponent<ProcessController>(); 
            //<%YAP#INITIALISER-CALL%>
        }
        private void Start() {
            //<%YAP#ATOMIC-EVENT-SUBSCRIPTIONS%>            
        }
        private void Update() {
            // Run every frame by Unity, regardless
            UpdateGuards();
        }
        #endregion

        #region Scenario Handlers
        //<%YAP#INTVARS%>

        //<%YAP#CALLBACKS%>
        #endregion

        #region Message interactions
        //<%YAP#HELPERS%>
        #endregion
    }

    public class SafetyControllerMessage : Message {}
}
