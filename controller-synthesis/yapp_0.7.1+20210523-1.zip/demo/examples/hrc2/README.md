# Supplemental Material on Controller Synthesis with YAP

CC-BY-NC 4.0, (c) Mario Gleirscher

This package provides additional materials to run the YAP-driven
synthesis experiments being part of the
[CSI:Cobot](https://www.sheffield.ac.uk/sheffieldrobotics/about/csi-cobots/planning)
case study.


## Package Content

  1. This README
  2. YAP executable (to be installed from *.deb or unzipped)
  3. YAP manual; see the [installed](/usr/share/yapp/doc/manual.pdf)
     or [unzipped](../../doc/manual.pdf) version
  4. Example files for the case study


## System Requirements

  1. Ubuntu 18.04+
  2. PRISM 4.5 installed;
     on Linux in `/opt/prism-4.5-linux64/bin/prism`;
     see the [PRISM website](www.prismmodelchecker.org) for details
  3. EvoChecker installed;
	 see the [EvoChecker
	 website](https://www-users.cs.york.ac.uk/~simos/EvoChecker/) for
	 details
  4. YAP installed;
	 see the YAP manual [here](/usr/share/yapp/doc/manual.pdf) or
	 [here](../../doc/manual.pdf) for details
  5. (Optional) Postprocessing tools installed; GraphViz,
     [Matplotlib](https://matplotlib.org/) (needs Python 3)

The experiment has only been run on a Ubuntu 20.04 machine.  Other
Linux variants and Mac might work, Windows won't because of **run.sh**
being a Bash script that needs to be at least partially ported.


## Run the Experiment

 1. **When installed from *.deb:** To copy the example files into a
    writable folder, use
    
	```
    mkdir -p ~/yap-examples/hrc2
	cp -r /usr/share/yapp/examples/hrc2 ~/yap-examples/hrc2
    ```
	Eventhough you can run the experiment several times, I recommend to
	make a fresh copy!
 
 2. To run the default steps of the experiment, call 

	`./run.sh`

	from a Bourne shell.  This Bash script executes YAP, EvoChecker,
	PRISM, and performs further postprocessing steps.  The output is
	stored in sub-folders named "xy-processingstage" where
	*processingstage* should largely explain itself.

Use *./run.sh -h* to get help on further steps/processing options.

Please, have a look into our
[ICECCS'20](https://ieeexplore.ieee.org/document/9376211) and
[FMAS'20](https://arxiv.org/abs/2012.01649) papers for further
discussion and examples.

  
