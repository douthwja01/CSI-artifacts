#!/bin/bash
# set -x

# ICECCS 2020 - script for running experiments
# CC-BY-NC 4.0, (c) Mario Gleirscher

USAGE="
Usage: ${0} [-chk|-debug]
       
       This script runs the experiment for the ICECCS20 paper. 
       By default, a controller is generated, followed by the generation 
       and verification of policies.

       -chk     verify policies, do not generate controller
       -debug   generate information for debugging
"

PRISM=/opt/prism-4.5-linux64/bin/prism
YAPTOOLDIR=/usr/share/yapp/tools/
ACT=off
TPL=cobot23
declare -A MDPPROP
MDPPROP=([a]="multi(R{\"potential\"}max=? [ C ], Pmax=? [ F hFINAL_CUSTOM ])" # a
         [b]="multi(R{\"prod\"}max=? [ C ], Pmax=? [ F hFINAL_CUSTOM ])"      # b
         [c]="multi(R{\"effort\"}max=? [ C ], R{\"nuisance\"}max=? [ C ])")   # c
ACCFREED="filter(count, \"ANYREC\" & !\"MISHAP\");\
          filter(avg, Pmin=? [ !\"ACCIDENT\" W \"SAFE\" ], \"ANYREC\" & !\"MISHAP\"); \
          filter(range, Pmin=? [ !\"ACCIDENT\" W \"SAFE\" ], \"ANYREC\" & !\"MISHAP\"); \
          filter(range, Pmin=? [ F \"hFINAL_CUSTOM\"], \"init\"); \
          filter(range, Pmax=? [ F \"hFINAL_CUSTOM\"], \"init\")"

################################################################################
# NOTE: Modify to select model increments and optimisation queries.
# All increments and queries
INC="01 02 03 04 05 06 07"
QUERIES="a b c"
################################################################################
# Increment 7 and query a
INC=01
QUERIES=a
################################################################################

for F in ${INC}; do
    for Q in ${QUERIES}; do
	YAPINMOD=${F}-input/${ACT}
	YAPINTPL=${F}-input/${TPL}-tpl.prism
	YAPOUT=${F}-input/output/${ACT}-${TPL}.prism
	# MDPOUT=${F}-output-mdp
	POLOUT=${F}-output-pol-${Q}/
	# generate MDP
        if [[ -z "${1}" ]] || [[ "${1}" != "-chk" ]]; then
	    echo "Generating controller design space with YAP ..."
	    ${YAPTOOLDIR}yap-debug.sh -o ${POLOUT} --gen-ctr-spc ${YAPINMOD} \
			 ${YAPINTPL} ${YAPOUT}
	    echo "Synthesising controller with PRISM ..."
	    ${YAPTOOLDIR}yap-debug.sh -o ${POLOUT} --syn-ctr ${YAPOUT} \
			 "${MDPPROP[${Q}]}" # --mdp
	    if [[ $? -ne 0 ]]; then
		echo "Synthesis failed. Won't continue."
		exit 1
	    fi
        elif [[ "${1}" == "-debug" ]]; then
	    tail -n 100 ~/.yap/yap.log > ${POLOUT}${ACT}-${TPL}-debug.txt
	    echo -e "\n\n" >> ${POLOUT}${ACT}-${TPL}-debug.txt
	    ${YAPTOOLDIR}yap-debug.sh -o ${POLOUT} --debug ${YAPOUT}
        fi
        # posterior check of design space / MDP (for debugging)
	${PRISM} \
            ${YAPOUT} \
	    -mdp \
	    -pctl "${ACCFREED}" \
	    -gs >${POLOUT}${ACT}-${TPL}-checks-mdp.txt
        # posterior check of policy / DTMC
	${PRISM} \
            -importstates ${POLOUT}${ACT}-${TPL}-adv.sta \
	    -importlabels ${POLOUT}${ACT}-${TPL}-adv.lab \
            -importtrans ${POLOUT}${ACT}-${TPL}-adv1.tra \
	    -dtmc \
	    -pctl "${ACCFREED/min/}" \
	    -gs >${POLOUT}${ACT}-${TPL}-checks-pol.txt
        # visualise policy and controller fragment
        for a in ${POLOUT}${ACT}-${TPL}-adv*.tra; do
            TMPOUT=${a%.*}
            echo "Processing/visualising adversary ${TMPOUT} (only if < 3000 states) ..."
            ${YAPTOOLDIR}yap-debug.sh -o ${POLOUT} --vis-ctr ${TMPOUT} --ctr 
            cp ${TMPOUT}.pdf ${TMPOUT/-adv/-ctr}.pdf
            ${YAPTOOLDIR}yap-debug.sh -o ${POLOUT} --vis-ctr ${TMPOUT} # --mdp
            # ${YAPTOOLDIR}yap-debug.sh -o ${POLOUT} --chk-ctr ${TMPOUT} ${CTRPROPS}
            echo "Done."
        done
    done
done
