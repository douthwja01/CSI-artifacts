# Supplemental Material (Demo) for ICECCS'20 Submission

CC-BY-NC 4.0, (c) Mario Gleirscher

This package provides additional materials to evaluate the manuscript
titled "Safety Controller Synthesis for Collaborative Robots"
submitted to ICECCS'20 in Singapore.


## Demo Package Content

  1. This README
  2. YAP executable (to be installed)
  3. YAP manual
  4. Example files for the paper


## Demo System Requirements

  1. Ubuntu 18.04+
  2. PRISM 4.5 installed 
     on Linux in /opt/prism-4.5-linux64/bin/prism
     see the [PRISM website](www.prismmodelchecker.org) for details
  3. YAP installed, see manual

Although I have tested YAP under Windows 10, the scripts prepared for
this article calling Yap and Prism and carry through postprocessing
with GraphViz, currently only run under Ubuntu.


## Demo Execution

To run the demo, call 

    ./run.sh 

from a Bourne shell.  This Bash script executes YAP, PRISM, and further
processing for seven model increments.

The output is stored in sub-folders "X-output-pol-Q", where X is the
model increment (01 to 07) and Q is the optimisation query (a,b,c)
matching Table IV in the paper.

My FMAS'20 paper, available [from arXiv](https://arxiv.org/abs/2012.01649), 
describes a workflow for the synthesis of safety controllers with YAP.

  
