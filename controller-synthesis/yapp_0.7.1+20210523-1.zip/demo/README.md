--------------------------------------------------------------------
YAP Against Perils
--------------------------------------------------------------------

Written by Mario Gleirscher (mario.gleirscher@tum.de)
Licensed under CC-BY-NC-SA 4.0

YAP is a risk modelling, analysis, and synthesis environment for
correct-by-design safety controllers for risk-aware autonomous
machines.

You can get more information about YAP from 

 1. the [YAP website at](http://yap.gleirscher.de): the website
    contains latest binaries and examples,
 2. the YAP manual [installed](/usr/share/yapp/doc/manual.pdf) or
    [unzipped](./doc/manual.pdf): the manual contains a comprehensive
    practically oriented introduction and several illustrative
    examples.  Start with Section 2.3, if you want to know how to use
    YAP from the command line.
 3. the YAP man page (if installed): type "man yapp" to have a compact
    overview of YAP's command-line interface.

Consider not printing the manual to protect our environment.
