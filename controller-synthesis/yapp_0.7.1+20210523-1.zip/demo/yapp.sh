#!/bin/bash
################################################################################
# YAP Tools: Integrator Script (to call external output processing tools)
# CC-BY-NC-SA 4.0 by 2020 Mario Gleirscher
# see http://creativecommons.org/licenses/by-nc-sa/4.0/
################################################################################

DEBUG=
YAP=java -jar /usr/share/yapp/yapp.jar
DATA=/usr/share/yapp/examples/

usage() {
    echo "Usage: $0 [-f <s|p|l|m|t>] [-d N] [-s] <package> <situation>" 1>&2
    exit 1
}

error() {
    echo "Error code ${?}"
    exit 1
}

# defaults for parameters
FORMAT=l
DETAIL=0
MODE=initial

# check and initialize parameters
while getopts "f:sd:" OPTION; do
    case ${OPTION} in
	f)
	    FORMAT=${OPTARG}
	    (( ("${FORMAT}" == "s") || ("${FORMAT}" == "l") \
		   || (${FORMAT} == "p") || (${FORMAT} == "m") \
		   || (${FORMAT} == "t") )) \
		|| usage
	    ;;
	s)
	    MODE=random
	    ;;
	d)
	    DETAIL=${OPTARG}
	    ;;
	*)
	    usage
	    ;;
    esac
done
shift $((OPTIND-1))

if [[ ${FORMAT} != "t" && $# < 2 ]]; then
    usage
fi

PACKAGE=${1}
MODEL=${2}
INPUT=${DATA}${PACKAGE}/${MODEL}
OUTPUT=~/yap-examples${PACKAGE}/output/${MODEL}

# perform
[ -n "$DEBUG" ] && set -e -x

if [ ${FORMAT} == "p" ]; then
    ${YAP} -l 3 --config ${INPUT}.yap \
	   -f plain --simulate ${MODE} > ${OUTPUT}.dot || error
    echo Post Yap data processing ...
    dot -Tpdf ${OUTPUT}.dot -o ${OUTPUT}.tmp.pdf || error
    pdfcrop --noverbose ${OUTPUT}.tmp.pdf ${OUTPUT}.pdf || error
    rm ${OUTPUT}.tmp.pdf
    
elif [ ${FORMAT} == "l" ]; then
    ${YAP} -v ${DETAIL} -l 3 --config ${INPUT}.yap -f latex \
	   --simulate ${MODE} > ${OUTPUT}.dot || error
    echo Post Yap data processing ...
    dot2tex --autosize --figpreamble="\large" -c -f tikz \
	    -t raw -o ${OUTPUT}.tex ${OUTPUT}.dot || error
    pdflatex -interaction=nonstopmode \
	     -output-directory=${DATA}output/ ${OUTPUT}.tex || error
elif [ ${FORMAT} == "s" ]; then
    echo ${OUTPUT}
    ${YAP} -v ${DETAIL} -l 3 --config ${INPUT}.yap \
	   -m situations > ${OUTPUT}.dot || error
    echo Post Yap data processing ...
    dot2tex --autosize --figpreamble="\large" -c -f tikz \
	    -t raw -o ${OUTPUT}.tex ${OUTPUT}.dot || error
    pdflatex -interaction=nonstopmode \
	     -output-directory=${DATA}output/ ${OUTPUT}.tex || error
    
elif [ ${FORMAT} == "m" ]; then
    ${YAP} -l 3 --config ${INPUT}.yap -m || error
    
elif [ ${FORMAT} == "t" ]; then
    ${YAP} -t || error
fi

